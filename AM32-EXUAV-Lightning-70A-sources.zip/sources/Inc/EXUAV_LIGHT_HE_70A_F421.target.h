/*
 * Cible AM32 custom — Exuav / MAD Motors Light HE 70A 3-6S (AT32F421)
 *
 * Base moteur : AT32DEV_F421 (documenté NeutronRC / MAD Motors)
 * LED RGB     : broches confirmées via ODDITYRC_F80_F421 (PB8/PB5/PB3)
 *
 * À insérer dans Inc/targets.h (AM32 v2.20), juste après le bloc AT32DEV_F421.
 */

#ifdef EXUAV_LIGHT_HE_70A_F421
#define FIRMWARE_NAME "ExuavHE70 "
#define FILE_NAME "EXUAV_LIGHT_HE_70A_F421"
#define DEAD_TIME 60
#define HARDWARE_GROUP_AT_B
#define HARDWARE_GROUP_AT_045
#define USE_SERIAL_TELEMETRY
#define CURRENT_ADC_CHANNEL ADC_CHANNEL_3
#define CURRENT_ADC_PIN GPIO_PINS_3
#define VOLTAGE_ADC_CHANNEL ADC_CHANNEL_6
#define VOLTAGE_ADC_PIN GPIO_PINS_6
#define USE_RGB_LED
#define LED_ARM_COLOR_USE_HALL
#define RED_PORT GPIOB
#define RED_PIN GPIO_PINS_8
#define GREEN_PORT GPIOB
#define GREEN_PIN GPIO_PINS_5
#define BLUE_PORT GPIOB
#define BLUE_PIN GPIO_PINS_3
#endif
