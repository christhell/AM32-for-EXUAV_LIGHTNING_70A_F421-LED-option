# Sources — Exuav Lightning 70A (AM32 v2.20)

Patches et fichiers pour recompiler les firmwares à partir du dépôt officiel [AM32 v2.20](https://github.com/am32-firmware/AM32/tree/v2.20).

## Contenu

| Fichier | Description |
|---------|-------------|
| `exuav-lightning-70a-v2.20.patch` | Patch `Src/main.c` (LED + fix Hall Sensors) |
| `Inc/targets.exuav.snippet.h` | Blocs cible à insérer dans `Inc/targets.h` |
| `Inc/EXUAV_LIGHT_HE_70A_F421.target.h` | Référence cible HE (copie du snippet HE) |
| `Inc/EXUAV_LIGHTNING_70A_F421.target.h` | Référence cible Lightning |
| `build_exuav_firmwares.sh` | Script de compilation des 2 variantes |

## Application sur AM32 v2.20

```bash
git clone --branch v2.20 --depth 1 https://github.com/am32-firmware/AM32.git AM32-exuav
cd AM32-exuav

# 1. Patch main.c
patch -p1 < /chemin/vers/exuav-lightning-70a-v2.20.patch

# 2. Ajouter les cibles dans Inc/targets.h
#    Ouvrir Inc/targets.h, repérer la fin du bloc AT32DEV_F421 (#endif ligne ~697)
#    Coller le contenu de Inc/targets.exuav.snippet.h juste avant #ifdef ZTW_A_F421

# 3. Copier le script de build à la racine du repo
cp /chemin/vers/build_exuav_firmwares.sh .
chmod +x build_exuav_firmwares.sh

# 4. Compiler
./build_exuav_firmwares.sh
```

Les `.hex` sont générés dans `obj/` :

- `AM32_EXUAV_LIGHTNING_70A_F421_2.20.hex`
- `AM32_EXUAV_LIGHT_HE_70A_F421_2.20.hex`

## Prérequis

- `make`
- Toolchain `arm-none-eabi-gcc` (fournie par AM32 via `make arm_sdk_install`, ou Arduino IDE)

Sur macOS, si la toolchain AM32 n'est pas installée, le script utilise automatiquement celle d'Arduino IDE.

## Licence

Ces modifications s'appliquent sur [AM32](https://github.com/am32-firmware/AM32), publié sous **GPLv3**.  
Distribuer les binaires `.hex` implique de mettre ces sources à disposition des utilisateurs.
