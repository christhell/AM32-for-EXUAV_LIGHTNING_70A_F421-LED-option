#!/bin/bash
# Build AM32 firmwares for Exuav / MAD Motors Lightning 70A ESC
set -euo pipefail

REPO_DIR="$(cd "$(dirname "$0")" && pwd)"
TARGETS=(
  "EXUAV_LIGHT_HE_70A_F421"
  "EXUAV_LIGHTNING_70A_F421"
)

if [[ ! -f "$REPO_DIR/Makefile" ]]; then
  echo "Erreur: lancez ce script depuis AM32-custom (Makefile absent)."
  exit 1
fi

for TARGET in "${TARGETS[@]}"; do
  if ! grep -q "$TARGET" "$REPO_DIR/Inc/targets.h"; then
    echo "Erreur: cible $TARGET absente de Inc/targets.h"
    exit 1
  fi
done

# Toolchain : AM32 embarquée, ou fallback Arduino (macOS)
AM32_GCC="$REPO_DIR/tools/macos/xpack-arm-none-eabi-gcc-10.3.1-2.3/bin/arm-none-eabi-gcc"
ARDUINO_GCC="/Applications/Arduino.app/Contents/Java/hardware/tools/arm/bin/arm-none-eabi-gcc"

if [[ -x "$AM32_GCC" ]]; then
  export ARM_SDK_PREFIX="$REPO_DIR/tools/macos/xpack-arm-none-eabi-gcc-10.3.1-2.3/bin/arm-none-eabi-"
elif [[ -x "$ARDUINO_GCC" ]]; then
  export ARM_SDK_PREFIX="/Applications/Arduino.app/Contents/Java/hardware/tools/arm/bin/arm-none-eabi-"
else
  echo "Installation toolchain AM32..."
  make -C "$REPO_DIR" arm_sdk_install
  if [[ -x "$AM32_GCC" ]]; then
    export ARM_SDK_PREFIX="$REPO_DIR/tools/macos/xpack-arm-none-eabi-gcc-10.3.1-2.3/bin/arm-none-eabi-"
  elif [[ -x "$ARDUINO_GCC" ]]; then
    export ARM_SDK_PREFIX="/Applications/Arduino.app/Contents/Java/hardware/tools/arm/bin/arm-none-eabi-"
  else
    echo "Erreur: aucune toolchain arm-none-eabi-gcc trouvée."
    exit 1
  fi
fi

for TARGET in "${TARGETS[@]}"; do
  echo "Compilation $TARGET..."
  make -C "$REPO_DIR" ARM_SDK_PREFIX="$ARM_SDK_PREFIX" "$TARGET"
  HEX="$REPO_DIR/obj/AM32_${TARGET}_2.20.hex"
  cp -f "$HEX" "$HOME/Downloads/AM32_${TARGET}_2.20.hex"
  echo "OK -> $HOME/Downloads/AM32_${TARGET}_2.20.hex"
done
